# Neon Arcade

A neon-themed browser arcade featuring four mini-games. Built with plain HTML, CSS, and JavaScript — no framework, package manager, or build step required.

## Games

- **Tic Tac Toe** — play against the CPU or a friend.
- **Connect Four** — drop discs and connect four.
- **Rock Paper Scissors** — play against the CPU or locally with a second player.
- **Reaction Duel** — test your reaction speed with touch or keyboard controls.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

For the most consistent local development experience, you can also run a simple local server from this folder:

```bash
python -m http.server 8000
```

Then open <http://localhost:8000>.

## Publish with GitHub Pages

1. Create a GitHub repository, for example `neon-arcade`.
2. Upload `index.html`, `style.css`, `script.js`, and this `README.md` to the repository root.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

## Project structure

```text
neon-arcade/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Notes

- Google Fonts are loaded online; system fonts are used as fallbacks.
- No backend or API keys are needed.
- The games run in the browser and do not require a build step.
