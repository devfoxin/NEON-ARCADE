const $=s=>document.querySelector(s);
const home=$('#home'),stage=$('#stage'),board=$('#board'),statusEl=$('#status'),againBtn=$('#again');
let cur,mode=1,score=[0,0],names=['You','CPU'],run=0,keyHandler=null;
document.addEventListener('keydown',e=>keyHandler&&keyHandler(e));

const wn=p=>names[p]+(names[p]==='You'?' win':' wins');
const tn=p=>mode===1?(p?'CPU is thinking…':'Your turn'):`${names[p]}’s turn`;
const setStatus=(t,c='')=>{statusEl.textContent=t;statusEl.className=c};
function drawScore(){$('#score').innerHTML=[0,1].map(i=>`<div class="sc s${i}"><span>${names[i]}</span><b>${score[i]}</b></div>`).join('')}
function endRound(w,msg){if(w>=0)score[w]++;drawScore();setStatus(msg||(w<0?'It’s a draw':wn(w)),w<0?'':'w'+w);againBtn.hidden=false}

const games={
  ttt:{name:'Tic Tac Toe',icon:'✕ ○',color:'var(--pink)',blurb:'Three in a row wins. The CPU plays smart.',init:ttt},
  c4:{name:'Connect Four',icon:'● ●',color:'var(--cyan)',blurb:'Drop discs. Line up four.',init:c4},
  rps:{name:'Rock Paper Scissors',icon:'✊ ✌',color:'var(--lime)',blurb:'Pure instinct. In 2P mode picks stay hidden.',init:rps},
  rx:{name:'Reaction Duel',icon:'⚡',color:'var(--violet)',blurb:'Wait for green, then tap first. Jump early and you lose.',init:rx}
};
$('#grid').innerHTML=Object.entries(games).map(([id,g])=>`<button class="card" data-id="${id}" style="--c:${g.color}"><span class="ic">${g.icon}</span><b>${g.name}</b><span>${g.blurb}</span><i>1P or 2P</i></button>`).join('');
$('#grid').onclick=e=>{const c=e.target.closest('.card');if(c)openGame(c.dataset.id)};
$('#back').onclick=()=>{run++;keyHandler=null;stage.hidden=true;home.hidden=false};
$('#mode').onclick=e=>{const b=e.target.closest('button');if(b)setMode(+b.dataset.m)};
againBtn.onclick=start;

function openGame(id){cur=id;home.hidden=true;stage.hidden=false;$('#gtitle').textContent=games[id].name;$('#gtitle').style.setProperty('--c',games[id].color);setMode(1)}
function setMode(m){mode=m;score=[0,0];names=m===1?['You','CPU']:['P1','P2'];document.querySelectorAll('#mode button').forEach(b=>b.setAttribute('aria-pressed',+b.dataset.m===m));start()}
function start(){run++;keyHandler=null;board.innerHTML='';board.style.cssText='';board.className='board '+cur;againBtn.hidden=true;againBtn.textContent=cur==='rps'?'Next round':'Play again';setStatus('');drawScore();games[cur].init()}

/* Tic Tac Toe */
function ttt(){
  const id=run,b=Array(9).fill(''),L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  let t=0,over=false;
  const win=d=>L.find(l=>d[l[0]]&&d[l[0]]===d[l[1]]&&d[l[0]]===d[l[2]]);
  board.style.setProperty('--cols',3);
  const cells=b.map((_,i)=>{const c=document.createElement('button');c.className='cell';c.setAttribute('aria-label','Cell '+(i+1));c.onclick=()=>play(i);board.append(c);return c});
  setStatus(tn(0));
  function play(i,cpu){
    if(id!==run||over||b[i]||(mode===1&&t===1&&!cpu))return;
    b[i]=t?'O':'X';cells[i].textContent=b[i];cells[i].classList.add(t?'o':'x');
    const w=win(b);
    if(w){over=true;w.forEach(k=>cells[k].classList.add('hit'));return endRound(t)}
    if(b.every(Boolean)){over=true;return endRound(-1)}
    t^=1;setStatus(tn(t));
    if(mode===1&&t===1)setTimeout(()=>play(best(),true),450);
  }
  function best(){
    const free=b.map((v,i)=>v?-1:i).filter(i=>i>=0);
    if(Math.random()<.2)return free[Math.random()*free.length|0];
    let bs=-99,bm=free[0];
    for(const i of free){b[i]='O';const s=mm(false,0);b[i]='';if(s>bs){bs=s;bm=i}}
    return bm;
  }
  function mm(max,d){
    if(win(b))return max?-10+d:10-d;
    if(b.every(Boolean))return 0;
    let r=max?-99:99;
    for(let i=0;i<9;i++)if(!b[i]){b[i]=max?'O':'X';const s=mm(!max,d+1);b[i]='';r=max?Math.max(r,s):Math.min(r,s)}
    return r;
  }
}

/* Connect Four */
function c4(){
  const id=run,R=6,C=7,g=Array.from({length:R},()=>Array(C).fill(-1));
  let t=0,over=false;
  board.style.setProperty('--cols',C);
  const cells=[];
  for(let r=0;r<R;r++)for(let c=0;c<C;c++){const e=document.createElement('button');e.className='cell disc';e.setAttribute('aria-label','Column '+(c+1));e.onclick=()=>drop(c);board.append(e);cells.push(e)}
  const at=(r,c)=>cells[r*C+c];
  const row=c=>{for(let r=R-1;r>=0;r--)if(g[r][c]<0)return r;return -1};
  const four=(r,c,p)=>{
    for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){
      const line=[[r,c]];
      for(const s of[1,-1]){let i=r+dr*s,j=c+dc*s;while(i>=0&&i<R&&j>=0&&j<C&&g[i][j]===p){line.push([i,j]);i+=dr*s;j+=dc*s}}
      if(line.length>=4)return line;
    }
    return null;
  };
  setStatus(tn(0));
  function drop(c,cpu){
    if(id!==run||over||row(c)<0||(mode===1&&t===1&&!cpu))return;
    const r=row(c);g[r][c]=t;at(r,c).classList.add('p'+t);
    const w=four(r,c,t);
    if(w){over=true;w.forEach(([i,j])=>at(i,j).classList.add('hit'));return endRound(t)}
    if(g[0].every(v=>v>=0)){over=true;return endRound(-1)}
    t^=1;setStatus(tn(t));
    if(mode===1&&t===1)setTimeout(()=>drop(ai(),true),500);
  }
  function ai(){
    const ok=[...Array(C).keys()].filter(c=>row(c)>=0);
    for(const p of[1,0])for(const c of ok){const r=row(c);g[r][c]=p;const w=four(r,c,p);g[r][c]=-1;if(w)return c}
    const safe=ok.filter(c=>{const r=row(c);if(r<1)return true;g[r][c]=1;g[r-1][c]=0;const bad=four(r-1,c,0);g[r][c]=-1;g[r-1][c]=-1;return!bad});
    return(safe.length?safe:ok).sort((a,b)=>Math.abs(a-3)-Math.abs(b-3)+(Math.random()-.5)*2)[0];
  }
}

/* Rock Paper Scissors */
function rps(){
  const id=run,E=['✊','✋','✌️'],N=['Rock','Paper','Scissors'];
  let pick=null,step=0,done=false;
  board.innerHTML='<div class="duel"><div class="hand" id="r0">?</div><span>VS</span><div class="hand" id="r1">?</div></div><div class="picks"></div>';
  E.forEach((e,i)=>{const b=document.createElement('button');b.className='pick';b.innerHTML=e+'<small>'+N[i]+'</small>';b.onclick=()=>choose(i);board.querySelector('.picks').append(b)});
  setStatus(mode===1?'Pick your move':'P1: pick in secret');
  function choose(i){
    if(id!==run||done)return;
    if(mode===1)return reveal(i,Math.random()*3|0);
    if(step===0){pick=i;step=1;$('#r0').textContent='🔒';setStatus('P2: pick in secret')}
    else reveal(pick,i);
  }
  function reveal(a,b){
    done=true;$('#r0').textContent=E[a];$('#r1').textContent=E[b];
    endRound(a===b?-1:(a-b+3)%3===1?0:1);
  }
}

/* Reaction Duel */
function rx(){
  const id=run;
  let ph='wait',t0=0,tm,cm;
  board.innerHTML=`<div class="rx"><button class="pad p0"><small>${names[0]} · ${mode===2?'A':'Space'}</small><span>WAIT</span></button><button class="pad p1" ${mode===1?'disabled':''}><small>${names[1]}${mode===2?' · L':''}</small><span>WAIT</span></button></div>`;
  const pads=[...board.querySelectorAll('.pad')],lab=s=>pads.forEach(p=>p.lastChild.textContent=s);
  pads[0].onpointerdown=()=>hit(0);
  if(mode===2)pads[1].onpointerdown=()=>hit(1);
  keyHandler=e=>{if(e.repeat)return;const k=e.key.toLowerCase();if(k===' '||k==='a'){e.preventDefault();hit(0)}else if(mode===2&&k==='l')hit(1)};
  setStatus('Wait for green. Tap early and you lose the round.');
  tm=setTimeout(()=>{
    if(id!==run)return;
    ph='go';t0=performance.now();lab('TAP!');board.classList.add('go');
    if(mode===1)cm=setTimeout(()=>hit(1),220+Math.random()*260);
  },1500+Math.random()*2500);
  function hit(p){
    if(id!==run||ph==='done')return;
    clearTimeout(tm);clearTimeout(cm);
    if(ph==='wait'){ph='done';return endRound(1-p,`${names[p]} tapped too early. ${wn(1-p)}`)}
    ph='done';
    endRound(p,`${wn(p)} in ${Math.round(performance.now()-t0)} ms`);
  }
}
